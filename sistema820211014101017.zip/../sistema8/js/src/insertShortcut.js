function loginInsertShortcut(buttonid){
  
  document.body.setAttribute("openlogin","1");
  document.getElementById(buttonid).click();
  
}