function goToMedicLogin(){
  
  document.body.setAttribute("openlogin","1");
  document.getElementById('btInsertMedico').click();
  
}