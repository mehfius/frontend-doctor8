
function formCustomEdit(areas){
	
		formMount(areas,null,function(){
			
			document.body.setAttribute("loading","0");
      
      //var userinfo  = JSON.parse(localStorage.userinfo);
      

			
			gridShow();
			
		});

}