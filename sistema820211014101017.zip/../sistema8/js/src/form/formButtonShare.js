function btOptionsBtShare(){

	var bt = cE("icon");
			
			bt.setAttribute("action","share");
			bt.setAttribute("class","icon-share2");
			bt.onclick=(function(){

			});
  
	return bt;
	
}