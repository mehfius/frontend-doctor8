function inputTypeNumber(element){
  
  var key = element.keyCode;
  
  if(key == 189 || key == 69){
    
    return false;
      
  }else{
    
    return true;
    
  }


}