function loadNavSuite(){
  
  var navsuite = cE("navsuite");
  document.body.setAttribute("navsuite","0");
  
  document.body.appendChild(navsuite);

  
}