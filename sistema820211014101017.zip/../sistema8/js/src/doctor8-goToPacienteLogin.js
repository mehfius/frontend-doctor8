function goToPacienteLogin(){
  
  document.body.setAttribute("openlogin","1");
  document.getElementById('btInsertPaciente').click();
  window.scrollTo( 0, 0 );
}